// Inspired by illustrator Paul Blow's "Love in the Time of Corona".
// https://paulblow.bigcartel.com/product/love-in-the-time-of-corona